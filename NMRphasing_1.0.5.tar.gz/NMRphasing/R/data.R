#' This is an example data in NMRphasing
#'
#' This dataset contains sample data for NMRphasing.
#'
#' @format A data frame with two columns, one is for NMR data in complex format, the other one is ppm
#' @author Aixiang Jiang
"fdat"
